-- ============================================================
-- RINJANI4D — Setup SQL untuk Supabase
-- Jalankan query ini di: Supabase Dashboard → SQL Editor
-- ============================================================


-- ══════════════════════════════════════════════════════════════
-- LANGKAH 1: Buat tabel "matches"
-- ══════════════════════════════════════════════════════════════

CREATE TABLE IF NOT EXISTS public.matches (
  id          UUID            DEFAULT gen_random_uuid() PRIMARY KEY,
  league      TEXT            NOT NULL,
  team1       TEXT            NOT NULL,
  team2       TEXT            NOT NULL,
  match_time  TIMESTAMPTZ     NOT NULL,
  prediction  TEXT,           -- nullable: skor prediksi parlay
  logo1_url   TEXT,           -- nullable: public URL logo tim 1
  logo2_url   TEXT,           -- nullable: public URL logo tim 2
  created_at  TIMESTAMPTZ     DEFAULT now() NOT NULL
);

-- Index untuk query cepat berdasarkan waktu tanding
CREATE INDEX IF NOT EXISTS idx_matches_match_time ON public.matches (match_time ASC);


-- ══════════════════════════════════════════════════════════════
-- LANGKAH 2: Row Level Security (RLS)
-- ══════════════════════════════════════════════════════════════

-- Aktifkan RLS
ALTER TABLE public.matches ENABLE ROW LEVEL SECURITY;

-- Policy: Siapapun bisa membaca (user publik)
CREATE POLICY "Public can read matches"
  ON public.matches
  FOR SELECT
  USING (true);

-- Policy: Siapapun bisa insert (admin via anon key — proteksi via password di frontend)
-- Catatan: Untuk keamanan lebih tinggi, gunakan Supabase Auth + RLS berbasis user.
CREATE POLICY "Anyone can insert matches"
  ON public.matches
  FOR INSERT
  WITH CHECK (true);

-- Policy: Siapapun bisa delete (admin via frontend)
CREATE POLICY "Anyone can delete matches"
  ON public.matches
  FOR DELETE
  USING (true);


-- ══════════════════════════════════════════════════════════════
-- LANGKAH 3: Buat Storage Bucket "club-logos"
-- Lakukan VIA DASHBOARD (bukan SQL):
--   Supabase → Storage → New Bucket
--   Name: club-logos
--   Public bucket: ✅ CENTANG (agar logo bisa diakses publik)
-- ══════════════════════════════════════════════════════════════

-- Atau via SQL (jika menggunakan Supabase CLI / service role):
-- INSERT INTO storage.buckets (id, name, public)
-- VALUES ('club-logos', 'club-logos', true)
-- ON CONFLICT DO NOTHING;


-- ══════════════════════════════════════════════════════════════
-- LANGKAH 4: Storage Policy untuk bucket "club-logos"
-- (Jalankan setelah bucket dibuat)
-- ══════════════════════════════════════════════════════════════

-- Izinkan siapapun membaca file dari bucket
CREATE POLICY "Public read club logos"
  ON storage.objects
  FOR SELECT
  USING (bucket_id = 'club-logos');

-- Izinkan siapapun upload ke bucket (proteksi via password di frontend admin)
CREATE POLICY "Anyone can upload club logos"
  ON storage.objects
  FOR INSERT
  WITH CHECK (bucket_id = 'club-logos');


-- ══════════════════════════════════════════════════════════════
-- CONTOH DATA TEST (opsional, hapus setelah test)
-- ══════════════════════════════════════════════════════════════

/*
INSERT INTO public.matches (league, team1, team2, match_time, prediction)
VALUES
  ('PREMIER LEAGUE', 'Manchester City', 'Arsenal',     now() + interval '2 hours',  '2-1'),
  ('LA LIGA',        'Real Madrid',     'Barcelona',   now() + interval '4 hours',  '1-1'),
  ('SERIE A',        'Juventus',        'AC Milan',    now() + interval '5 hours',  'Over 2.5'),
  ('UCL',            'PSG',             'Bayern Munich', now() + interval '6 hours', 'Kedua tim cetak gol');
*/


-- ══════════════════════════════════════════════════════════════
-- RINGKASAN CARA DEPLOY
-- ══════════════════════════════════════════════════════════════
-- 1. Buka https://supabase.com dan buat project baru
-- 2. Jalankan SQL di atas di SQL Editor
-- 3. Buat Storage Bucket "club-logos" (public) via Dashboard → Storage
-- 4. Salin URL Project & Anon Key dari Settings → API
-- 5. Paste ke js/config.js (SUPABASE_URL & SUPABASE_ANON_KEY)
-- 6. Ganti ADMIN_PASSWORD di js/config.js
-- 7. Upload semua file ke Vercel (drag & drop folder)
-- 8. Akses /admin.html untuk mulai input jadwal
-- ══════════════════════════════════════════════════════════════
