// ============================================================
// js/config.js — RINJANI4D Configuration
// PENTING: Ganti nilai di bawah ini dengan kredensial Anda
// JANGAN pernah commit file ini ke repository publik!
// ============================================================

const CONFIG = {
  // Supabase credentials — ambil dari: https://supabase.com/dashboard/project/YOUR_PROJECT/settings/api
  SUPABASE_URL: "https://GANTI_DENGAN_URL_PROJECT_ANDA.supabase.co",
  SUPABASE_ANON_KEY: "GANTI_DENGAN_ANON_KEY_ANDA",

  // Password admin — WAJIB diganti sebelum deploy!
  ADMIN_PASSWORD: "rinjani4d@admin2024",

  // Link pendaftaran/login situs utama
  SITE_URL: "https://rinjani4d.com/daftar",

  // Nama Storage Bucket di Supabase (buat dulu via dashboard)
  STORAGE_BUCKET: "club-logos",

  // Nama tabel di Supabase Database
  TABLE_NAME: "matches",
};
